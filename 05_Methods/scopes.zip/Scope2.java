
class Scope2
{
	public static void main(String[] args)
	{
		if(5 > 7) {
			int n = 3;
	      System.out.println("n is " + 3);
		}
		else
		{
	      int n = 5;
	      System.out.println("n is " + 3);
		}
	}
}
