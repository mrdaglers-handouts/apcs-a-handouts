
class Scope3
{
   static void func()
   {
      int n = 3;
      System.out.println("n = " + n);
   }

	public static void main(String[] args)
	{
		func();

      System.out.println("n = " + n);
	}
}
