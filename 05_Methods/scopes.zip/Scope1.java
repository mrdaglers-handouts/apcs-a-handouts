
class Scope1
{
	public static void main(String[] args)
	{
		int n = 3;
      System.out.println("n is " + 3);

      int n = 5;
      System.out.println("n is " + 3);
	}
}
