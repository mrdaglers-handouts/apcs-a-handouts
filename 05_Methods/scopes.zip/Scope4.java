
class Scope3
{
   static void func()
   {
      int n = 3;
      System.out.println("n = " + n);
   }

	public static void main(String[] args)
	{
      int n = 5;
		func();

      System.out.println("n = " + n);
	}
}
